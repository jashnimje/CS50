from cs50 import get_string

# Ask for a string and store it in a variable
name = get_string("What is your name?\n")

# Print the given string with a name
print(f"hello, {name}")